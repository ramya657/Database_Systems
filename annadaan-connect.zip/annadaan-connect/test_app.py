"""Smoke + workflow tests.  Run with:  python test_app.py"""
import os
import tempfile
import unittest

_tmp = tempfile.mkdtemp()
os.environ["DB_PATH"] = os.path.join(_tmp, "test.db")

import app as app_module          # noqa: E402  (must come after DB_PATH is set)
import ml                         # noqa: E402
import seed                       # noqa: E402
import services as svc            # noqa: E402
import db as dbm                  # noqa: E402


class PlatformTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        seed.main(force=True)
        app_module.app.config["TESTING"] = True
        cls.client = app_module.app.test_client()

    def test_every_page_loads(self):
        urls = ["/", "/donors", "/donors/new", "/donors/1", "/donors/1/edit", "/ngos", "/ngos/new", "/ngos/1",
                "/ngos/1/edit", "/packages", "/packages?status=available", "/packages/new", "/requests",
                "/requests?status=pending", "/requests/new", "/assignments", "/assignments?status=picked_up",
                "/history", "/history.csv", "/insights", "/api/forecast", "/api/priority-queue"]
        for url in urls:
            with self.subTest(url=url):
                self.assertEqual(self.client.get(url).status_code, 200, url)
        self.assertEqual(self.client.get("/donors/99999").status_code, 404)

    def test_detail_pages_for_live_records(self):
        db = dbm.connect()
        pkg = db.execute("SELECT id FROM food_packages WHERE status='available' LIMIT 1").fetchone()["id"]
        req = db.execute("SELECT id FROM requests WHERE status IN ('pending','partial') LIMIT 1").fetchone()["id"]
        self.assertEqual(self.client.get(f"/packages/{pkg}").status_code, 200)
        self.assertEqual(self.client.get(f"/requests/{req}").status_code, 200)

    def test_full_workflow(self):
        c = self.client
        r = c.post("/donors/new", data={"name": "Test Donor", "donor_type": "Restaurant", "city": "Hyderabad"})
        self.assertEqual(r.status_code, 302)
        r = c.post("/ngos/new", data={"name": "Test NGO", "city": "Hyderabad", "beneficiaries": "30"})
        self.assertEqual(r.status_code, 302)
        db = dbm.connect()
        donor = db.execute("SELECT id FROM donors WHERE name='Test Donor'").fetchone()["id"]
        ngo = db.execute("SELECT id FROM ngos WHERE name='Test NGO'").fetchone()["id"]

        from datetime import datetime, timedelta
        soon = (datetime.now() + timedelta(hours=4)).strftime("%Y-%m-%dT%H:%M")
        r = c.post("/packages/new", data={"donor_id": donor, "food_name": "Test Rice", "category": "Cooked Meals",
                                          "servings": "40", "expiry_at": soon})
        self.assertEqual(r.status_code, 302)
        r = c.post("/requests/new", data={"ngo_id": ngo, "category": "Cooked Meals", "servings_needed": "25",
                                          "urgency": "5", "needed_by": soon})
        self.assertEqual(r.status_code, 302)
        pkg = db.execute("SELECT id FROM food_packages WHERE food_name='Test Rice'").fetchone()["id"]
        req = db.execute("SELECT id FROM requests WHERE ngo_id=?", (ngo,)).fetchone()["id"]

        # assign part, then the rest
        c.post("/assign", data={"package_id": pkg, "request_id": req, "servings": "25"})
        self.assertEqual(svc.get_request(db, req)["status"], "assigned")
        self.assertEqual(svc.get_package(db, pkg)["remaining"], 15)
        self.assertEqual(svc.get_package(db, pkg)["status"], "available")

        # over-allocation is rejected
        ok, _ = svc.create_assignment(db, pkg, req, 5)
        self.assertFalse(ok)

        aid = db.execute("SELECT id FROM assignments WHERE package_id=?", (pkg,)).fetchone()["id"]
        c.post(f"/assignments/{aid}/status", data={"status": "picked_up"})
        c.post(f"/assignments/{aid}/status", data={"status": "delivered"})
        self.assertEqual(svc.get_request(db, req)["status"], "fulfilled")
        hist = db.execute("SELECT servings FROM distribution_history WHERE assignment_id=?", (aid,)).fetchone()
        self.assertEqual(hist["servings"], 25)
        # delivered twice must not double count
        ok, _ = svc.update_assignment_status(db, aid, "delivered")
        self.assertFalse(ok)

    def test_cancel_request_releases_food(self):
        db = dbm.connect()
        ok, _ = svc.create_assignment(db, *self._fresh_pair(db))
        self.assertTrue(ok)
        req = db.execute("SELECT request_id, package_id FROM assignments ORDER BY id DESC LIMIT 1").fetchone()
        before = svc.get_package(db, req["package_id"])["remaining"]
        svc.cancel_request(db, req["request_id"])
        self.assertGreater(svc.get_package(db, req["package_id"])["remaining"], before - 1)
        self.assertEqual(svc.get_request(db, req["request_id"])["status"], "cancelled")

    def _fresh_pair(self, db):
        from datetime import datetime, timedelta
        d = db.execute("SELECT id FROM donors LIMIT 1").fetchone()["id"]
        n = db.execute("SELECT id FROM ngos LIMIT 1").fetchone()["id"]
        ts = lambda h: (datetime.now() + timedelta(hours=h)).strftime(svc.TS)
        p = db.execute("INSERT INTO food_packages (donor_id,food_name,category,servings,expiry_at,created_at) VALUES (?,?,?,?,?,?)",
                       (d, "Cancel test", "Bakery", 30, ts(10), svc.now_str())).lastrowid
        r = db.execute("INSERT INTO requests (ngo_id,category,servings_needed,beneficiaries,urgency,needed_by,created_at) VALUES (?,?,?,?,?,?,?)",
                       (n, "Bakery", 30, 20, 3, ts(12), svc.now_str())).lastrowid
        db.commit()
        return p, r

    def test_auto_assign_and_priority_order(self):
        db = dbm.connect()
        queue = ml.rank_requests(db)
        scores = [r["score"] for r in queue]
        self.assertEqual(scores, sorted(scores, reverse=True))
        ml.auto_assign(db)           # must not raise
        for p in svc.available_packages(db, 0):
            self.assertGreaterEqual(p["remaining"], 0)

    def test_forecast_shape(self):
        fc = ml.forecast(dbm.connect())
        self.assertEqual(len(fc["points"]), 7)
        self.assertTrue(all(p["demand"] >= 0 for p in fc["points"]))

    def test_validation_errors(self):
        r = self.client.post("/packages/new", data={"donor_id": "1", "food_name": "", "servings": "0"})
        self.assertEqual(r.status_code, 200)          # re-renders form with errors
        self.assertIn(b"Food name is required", r.data)
        r = self.client.post("/donors/new", data={"name": ""})
        self.assertIn(b"Donor name is required", r.data)


if __name__ == "__main__":
    unittest.main(verbosity=2)
