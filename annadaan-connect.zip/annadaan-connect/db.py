"""SQLite database layer: schema + connection helpers."""
import os
import sqlite3

from flask import g

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("DB_PATH", os.path.join(BASE_DIR, "food_donation.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS donors (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    name           TEXT NOT NULL,
    donor_type     TEXT NOT NULL DEFAULT 'Restaurant',
    contact_person TEXT DEFAULT '',
    phone          TEXT DEFAULT '',
    email          TEXT DEFAULT '',
    address        TEXT DEFAULT '',
    city           TEXT DEFAULT '',
    created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS ngos (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    name           TEXT NOT NULL,
    contact_person TEXT DEFAULT '',
    phone          TEXT DEFAULT '',
    email          TEXT DEFAULT '',
    address        TEXT DEFAULT '',
    city           TEXT DEFAULT '',
    beneficiaries  INTEGER NOT NULL DEFAULT 0,   -- people usually served
    capacity       INTEGER NOT NULL DEFAULT 0,   -- servings the NGO can handle per day
    created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS food_packages (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    donor_id       INTEGER NOT NULL REFERENCES donors(id) ON DELETE CASCADE,
    food_name      TEXT NOT NULL,
    category       TEXT NOT NULL,
    servings       INTEGER NOT NULL CHECK (servings > 0),
    quantity_note  TEXT DEFAULT '',
    pickup_address TEXT DEFAULT '',
    city           TEXT DEFAULT '',
    prepared_at    TEXT,
    expiry_at      TEXT NOT NULL,
    status         TEXT NOT NULL DEFAULT 'available',  -- available | assigned | delivered | expired | withdrawn
    notes          TEXT DEFAULT '',
    created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS requests (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ngo_id          INTEGER NOT NULL REFERENCES ngos(id) ON DELETE CASCADE,
    category        TEXT NOT NULL DEFAULT 'Any',
    servings_needed INTEGER NOT NULL CHECK (servings_needed > 0),
    beneficiaries   INTEGER NOT NULL DEFAULT 0,
    urgency         INTEGER NOT NULL DEFAULT 3 CHECK (urgency BETWEEN 1 AND 5),
    needed_by       TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'pending',   -- pending | partial | assigned | fulfilled | cancelled
    notes           TEXT DEFAULT '',
    created_at      TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS assignments (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    package_id     INTEGER NOT NULL REFERENCES food_packages(id) ON DELETE CASCADE,
    request_id     INTEGER NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
    servings       INTEGER NOT NULL CHECK (servings > 0),
    status         TEXT NOT NULL DEFAULT 'assigned',   -- assigned | picked_up | delivered | cancelled
    assigned_at    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    picked_up_at   TEXT,
    delivered_at   TEXT,
    notes          TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS distribution_history (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    assignment_id INTEGER NOT NULL UNIQUE REFERENCES assignments(id) ON DELETE CASCADE,
    donor_id      INTEGER NOT NULL REFERENCES donors(id) ON DELETE CASCADE,
    ngo_id        INTEGER NOT NULL REFERENCES ngos(id) ON DELETE CASCADE,
    food_name     TEXT NOT NULL,
    category      TEXT NOT NULL,
    servings      INTEGER NOT NULL,
    delivered_at  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_packages_status  ON food_packages(status, expiry_at);
CREATE INDEX IF NOT EXISTS idx_requests_status  ON requests(status, needed_by);
CREATE INDEX IF NOT EXISTS idx_assign_package   ON assignments(package_id);
CREATE INDEX IF NOT EXISTS idx_assign_request   ON assignments(request_id);
CREATE INDEX IF NOT EXISTS idx_history_ngo      ON distribution_history(ngo_id, delivered_at);
"""


def connect(path=None):
    conn = sqlite3.connect(path or DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def get_db():
    if "db" not in g:
        g.db = connect()
    return g.db


def close_db(exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db(path=None):
    conn = connect(path)
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()
