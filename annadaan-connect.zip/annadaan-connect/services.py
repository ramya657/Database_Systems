"""Business logic: packages, requests, assignments and status bookkeeping.

Every function takes an explicit sqlite connection so it can be used from Flask
routes, the seed script and tests alike.
"""
from datetime import datetime, timedelta

TS = "%Y-%m-%d %H:%M"

CATEGORIES = [
    "Cooked Meals",
    "Bakery",
    "Fruits & Vegetables",
    "Dairy",
    "Packaged Food",
    "Grains & Staples",
]
DONOR_TYPES = [
    "Restaurant", "Caterer", "Banquet Hall", "Supermarket",
    "Bakery", "Institution", "Wholesale Market", "Individual",
]
URGENCY_LABELS = {
    1: "1 – Low (routine top-up)",
    2: "2 – Normal",
    3: "3 – Important",
    4: "4 – Urgent",
    5: "5 – Critical (people going hungry)",
}


def now():
    return datetime.now()


def now_str():
    return now().strftime(TS)


def parse(value):
    """Parse 'YYYY-MM-DD HH:MM[:SS]' into a datetime."""
    return datetime.strptime(value[:16], TS)


# --------------------------------------------------------------------------
# Queries
# --------------------------------------------------------------------------
PKG_SELECT = """
SELECT p.*, d.name AS donor_name, d.phone AS donor_phone,
       COALESCE((SELECT SUM(a.servings) FROM assignments a
                 WHERE a.package_id = p.id AND a.status != 'cancelled'), 0) AS allocated
FROM food_packages p JOIN donors d ON d.id = p.donor_id
"""

REQ_SELECT = """
SELECT r.*, n.name AS ngo_name, n.city AS ngo_city, n.address AS ngo_address, n.phone AS ngo_phone,
       COALESCE((SELECT SUM(a.servings) FROM assignments a
                 WHERE a.request_id = r.id AND a.status != 'cancelled'), 0) AS allocated
FROM requests r JOIN ngos n ON n.id = r.ngo_id
"""


def _pkg(row):
    d = dict(row)
    d["remaining"] = max(0, d["servings"] - d["allocated"])
    return d


def _req(row):
    d = dict(row)
    d["remaining"] = max(0, d["servings_needed"] - d["allocated"])
    return d


def scalar(db, sql, params=()):
    return db.execute(sql, params).fetchone()[0]


def get_package(db, package_id):
    row = db.execute(PKG_SELECT + " WHERE p.id = ?", (package_id,)).fetchone()
    return _pkg(row) if row else None


def get_request(db, request_id):
    row = db.execute(REQ_SELECT + " WHERE r.id = ?", (request_id,)).fetchone()
    return _req(row) if row else None


def list_packages(db, status=None, category=None):
    sql, params, where = PKG_SELECT, [], []
    if status:
        where.append("p.status = ?")
        params.append(status)
    if category:
        where.append("p.category = ?")
        params.append(category)
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY CASE p.status WHEN 'available' THEN 0 WHEN 'assigned' THEN 1 ELSE 2 END, p.expiry_at"
    if not status:
        sql += " LIMIT 300"
    return [_pkg(r) for r in db.execute(sql, params)]


def list_requests(db, status=None):
    sql, params = REQ_SELECT, []
    if status:
        sql += " WHERE r.status = ?"
        params.append(status)
    sql += " ORDER BY r.created_at DESC LIMIT 300"
    return [_req(r) for r in db.execute(sql, params)]


def available_packages(db, min_hours=1):
    """Packages that can still be assigned (with servings left, not about to expire)."""
    cutoff = (now() + timedelta(hours=min_hours)).strftime(TS)
    rows = db.execute(PKG_SELECT + " WHERE p.status = 'available' AND p.expiry_at > ? ORDER BY p.expiry_at", (cutoff,))
    return [p for p in map(_pkg, rows) if p["remaining"] > 0]


def expiring_packages(db, hours=12):
    limit = now() + timedelta(hours=hours)
    return [p for p in available_packages(db, 0) if parse(p["expiry_at"]) <= limit]


def assignments_for(db, where, params=(), limit=300):
    return db.execute(
        """SELECT a.*, p.food_name, p.category, p.pickup_address, p.city AS pkg_city,
                  d.name AS donor_name, d.phone AS donor_phone,
                  n.name AS ngo_name, n.phone AS ngo_phone, n.address AS ngo_address,
                  r.needed_by, r.ngo_id, p.donor_id
           FROM assignments a
           JOIN food_packages p ON p.id = a.package_id
           JOIN donors d ON d.id = p.donor_id
           JOIN requests r ON r.id = a.request_id
           JOIN ngos n ON n.id = r.ngo_id
           WHERE """ + where + " ORDER BY a.assigned_at DESC LIMIT ?", tuple(params) + (limit,)
    ).fetchall()


def recent_history(db, limit=8):
    return db.execute(
        """SELECT h.*, d.name AS donor_name, n.name AS ngo_name
           FROM distribution_history h
           JOIN donors d ON d.id = h.donor_id JOIN ngos n ON n.id = h.ngo_id
           ORDER BY h.delivered_at DESC LIMIT ?""", (limit,)
    ).fetchall()


def dashboard_stats(db):
    week_ago = (now() - timedelta(days=7)).strftime(TS)
    avail = available_packages(db, 0)
    soon = now() + timedelta(hours=6)
    return {
        "donors": scalar(db, "SELECT COUNT(*) FROM donors"),
        "ngos": scalar(db, "SELECT COUNT(*) FROM ngos"),
        "servings_delivered": scalar(db, "SELECT COALESCE(SUM(servings),0) FROM distribution_history"),
        "delivered_week": scalar(db, "SELECT COALESCE(SUM(servings),0) FROM distribution_history WHERE delivered_at >= ?", (week_ago,)),
        "open_requests": scalar(db, "SELECT COUNT(*) FROM requests WHERE status IN ('pending','partial')"),
        "available_packages": len(avail),
        "available_servings": sum(p["remaining"] for p in avail),
        "active_assignments": scalar(db, "SELECT COUNT(*) FROM assignments WHERE status IN ('assigned','picked_up')"),
        "expiring_soon": sum(1 for p in avail if parse(p["expiry_at"]) <= soon),
    }


# --------------------------------------------------------------------------
# Status bookkeeping
# --------------------------------------------------------------------------
def expire_packages(db):
    db.execute("UPDATE food_packages SET status='expired' WHERE status='available' AND expiry_at < ?", (now_str(),))


def refresh_package(db, package_id):
    pkg = get_package(db, package_id)
    if not pkg or pkg["status"] in ("expired", "withdrawn"):
        return
    active = scalar(db, "SELECT COUNT(*) FROM assignments WHERE package_id=? AND status IN ('assigned','picked_up')", (package_id,))
    if pkg["allocated"] >= pkg["servings"]:
        new = "delivered" if active == 0 else "assigned"
    else:
        new = "available"
    db.execute("UPDATE food_packages SET status=? WHERE id=?", (new, package_id))


def refresh_request(db, request_id):
    req = get_request(db, request_id)
    if not req or req["status"] == "cancelled":
        return
    active = scalar(db, "SELECT COUNT(*) FROM assignments WHERE request_id=? AND status IN ('assigned','picked_up')", (request_id,))
    if req["allocated"] >= req["servings_needed"]:
        new = "fulfilled" if active == 0 else "assigned"
    elif req["allocated"] > 0:
        new = "partial"
    else:
        new = "pending"
    db.execute("UPDATE requests SET status=? WHERE id=?", (new, request_id))


# --------------------------------------------------------------------------
# Commands
# --------------------------------------------------------------------------
def create_assignment(db, package_id, request_id, servings=None, notes=""):
    pkg = get_package(db, package_id)
    req = get_request(db, request_id)
    if not pkg or not req:
        return False, "Package or request not found."
    if pkg["status"] != "available":
        return False, "This package is no longer available."
    if parse(pkg["expiry_at"]) <= now():
        return False, "This package has already expired."
    if req["status"] not in ("pending", "partial"):
        return False, "This request is not open for new assignments."
    most = min(pkg["remaining"], req["remaining"])
    if most <= 0:
        return False, "There is nothing left to allocate."
    try:
        servings = most if servings in (None, "") else int(servings)
    except (TypeError, ValueError):
        return False, "Servings must be a number."
    if servings <= 0 or servings > most:
        return False, f"Servings must be between 1 and {most}."
    db.execute(
        "INSERT INTO assignments (package_id, request_id, servings, notes, assigned_at) VALUES (?,?,?,?,?)",
        (package_id, request_id, servings, notes, now_str()),
    )
    refresh_package(db, package_id)
    refresh_request(db, request_id)
    db.commit()
    return True, f"Assigned {servings} servings of {pkg['food_name']} to {req['ngo_name']}."


_TRANSITIONS = {
    "assigned": {"picked_up", "delivered", "cancelled"},
    "picked_up": {"delivered", "cancelled"},
}


def update_assignment_status(db, assignment_id, new_status):
    a = db.execute(
        """SELECT a.*, p.donor_id, p.food_name, p.category, r.ngo_id
           FROM assignments a JOIN food_packages p ON p.id = a.package_id
           JOIN requests r ON r.id = a.request_id WHERE a.id = ?""", (assignment_id,)
    ).fetchone()
    if not a:
        return False, "Assignment not found."
    if new_status not in _TRANSITIONS.get(a["status"], set()):
        return False, f"Cannot change an assignment from '{a['status']}' to '{new_status}'."
    ts = now_str()
    if new_status == "picked_up":
        db.execute("UPDATE assignments SET status='picked_up', picked_up_at=? WHERE id=?", (ts, assignment_id))
    elif new_status == "delivered":
        db.execute(
            "UPDATE assignments SET status='delivered', delivered_at=?, picked_up_at=COALESCE(picked_up_at, ?) WHERE id=?",
            (ts, ts, assignment_id),
        )
        db.execute(
            """INSERT OR IGNORE INTO distribution_history
               (assignment_id, donor_id, ngo_id, food_name, category, servings, delivered_at)
               VALUES (?,?,?,?,?,?,?)""",
            (assignment_id, a["donor_id"], a["ngo_id"], a["food_name"], a["category"], a["servings"], ts),
        )
    else:
        db.execute("UPDATE assignments SET status='cancelled' WHERE id=?", (assignment_id,))
    refresh_package(db, a["package_id"])
    refresh_request(db, a["request_id"])
    db.commit()
    return True, f"Assignment #{assignment_id} marked {new_status.replace('_', ' ')}."


def cancel_request(db, request_id):
    req = get_request(db, request_id)
    if not req:
        return False, "Request not found."
    if req["status"] in ("fulfilled", "cancelled"):
        return False, f"A {req['status']} request cannot be cancelled."
    pkg_ids = [r["package_id"] for r in db.execute(
        "SELECT package_id FROM assignments WHERE request_id=? AND status IN ('assigned','picked_up')", (request_id,))]
    db.execute("UPDATE requests SET status='cancelled' WHERE id=?", (request_id,))
    db.execute("UPDATE assignments SET status='cancelled' WHERE request_id=? AND status IN ('assigned','picked_up')", (request_id,))
    for pid in pkg_ids:
        refresh_package(db, pid)
    db.commit()
    return True, "Request cancelled. Any reserved food has been released."


def withdraw_package(db, package_id):
    pkg = get_package(db, package_id)
    if not pkg:
        return False, "Package not found."
    active = scalar(db, "SELECT COUNT(*) FROM assignments WHERE package_id=? AND status IN ('assigned','picked_up')", (package_id,))
    if pkg["status"] != "available" or active:
        return False, "Only available packages with no active assignments can be withdrawn."
    db.execute("UPDATE food_packages SET status='withdrawn' WHERE id=?", (package_id,))
    db.commit()
    return True, "Package withdrawn."
