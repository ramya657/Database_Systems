# Annadaan Connect – Food Donation Management Platform

A web platform that connects **food donors** (restaurants, caterers, shops, individuals) with **NGOs** that can
distribute surplus food. Built with **Flask + SQLite**, plus a small Python "smart" layer that prioritises
requests and forecasts demand.

## Quick start

```bash
# 1. (optional) create a virtual environment
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # macOS / Linux

# 2. install the only dependency
pip install -r requirements.txt

# 3. load demo data (8 weeks of history + a live queue)
python seed.py

# 4. run the website
python app.py
```

Open **http://127.0.0.1:5000**. The database file `food_donation.db` is created automatically.
Run `python seed.py --force` any time to reset to fresh demo data, or skip seeding to start empty.
Run `python test_app.py` to execute the automated tests.

## Core modules

| Module | What it does |
|---|---|
| **Donors** | Register donors, see their packages and total servings delivered |
| **Food packages** | List surplus food with servings, category, pickup address and a "use before" time. Expired food is flagged automatically |
| **NGOs** | Register organisations with people served and daily capacity |
| **Requests** | NGOs ask for food: category, servings, urgency (1–5), deadline |
| **Assignments** | Match package → request (partial quantities supported), then track *assigned → picked up → delivered* |
| **Distribution history** | Every completed delivery, top donors/NGOs, CSV export |
| **Insights** | Demand forecast and the explainable priority queue |

## The Python "smart" component (`ml.py`)

1. **Request prioritisation** – every open request gets a transparent 0–100 score:
   urgency (35) + deadline proximity (30) + people affected (15) + waiting time (10) + fair share (10).
   *Fair share* boosts NGOs that received less food in the last 14 days. Labels: Critical / High / Medium / Low.
2. **Matching** – for any package (or request) the app suggests the best counterpart, scoring category fit,
   city, quantity fit, and favouring food that expires soonest.
3. **Smart auto-assign** – one click assigns available food to the highest-priority requests first.
4. **Demand forecast** – predicts the next 7 days of requested servings (and expected donations) using a
   weekday-aware, recency-weighted average over the last 8 weeks, then flags the days where demand outruns supply.

JSON endpoints: `/api/priority-queue` and `/api/forecast`.

## Project structure

```
app.py          Flask routes (backend)
db.py           SQLite schema + connection helpers (database)
services.py     Business rules: assignments, status updates, stats
ml.py           Priority scoring, matching, auto-assign, forecasting
seed.py         Demo data generator
test_app.py     Automated tests
templates/      Jinja2 HTML pages (frontend)
static/         CSS
```

### Database tables
`donors` · `ngos` · `food_packages` · `requests` · `assignments` · `distribution_history`

## Ideas for taking it further
- User accounts & roles (donor / NGO / admin) with login – e.g. Flask-Login
- SMS / email alerts when a package is assigned or about to expire
- Map view and driver/volunteer assignment using real distances
- Swap SQLite for PostgreSQL/MySQL for production (only `db.py` needs to change)
- Set `SECRET_KEY` as an environment variable and run behind gunicorn when deploying
