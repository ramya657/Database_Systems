"""Smart features (pure Python, no heavy dependencies).

1. priority_score / rank_requests  - explainable 0-100 score used to order NGO requests.
2. suggest_*                       - match packages <-> requests.
3. auto_assign                     - greedy matcher that serves the highest-priority requests first.
4. forecast                        - weekday-aware demand/supply forecast (exponentially weighted).
"""
import math
from collections import defaultdict
from datetime import date, timedelta
from statistics import pstdev

import services as svc

# Maximum points each factor can contribute (sums to 100).
WEIGHTS = {"urgency": 35, "deadline": 30, "beneficiaries": 15, "waiting": 10, "fairness": 10}


def priority_label(score):
    if score >= 70:
        return "Critical"
    if score >= 50:
        return "High"
    if score >= 30:
        return "Medium"
    return "Low"


def priority_score(req, current=None, ngo_recent=0.0, avg_recent=0.0):
    """Explainable priority score between 0 and 100.

    urgency        - the NGO's own 1-5 rating
    deadline       - rises sharply as `needed_by` approaches (or has passed)
    beneficiaries  - more people affected -> higher (log scale so huge numbers don't dominate)
    waiting        - how long the request has been open (caps at 48h)
    fairness       - NGOs that received less food in the last 14 days get a boost
    """
    current = current or svc.now()
    urgency = (req["urgency"] - 1) / 4 * WEIGHTS["urgency"]

    hours_left = (svc.parse(req["needed_by"]) - current).total_seconds() / 3600
    deadline = WEIGHTS["deadline"] if hours_left <= 0 else WEIGHTS["deadline"] * math.exp(-hours_left / 24)

    people = max(int(req["beneficiaries"] or 0), 1)
    beneficiaries = min(WEIGHTS["beneficiaries"], WEIGHTS["beneficiaries"] * math.log10(people + 1) / math.log10(501))

    waited = max(0.0, (current - svc.parse(req["created_at"])).total_seconds() / 3600)
    waiting = min(WEIGHTS["waiting"], WEIGHTS["waiting"] * waited / 48)

    if avg_recent <= 0:
        fairness = WEIGHTS["fairness"] / 2
    else:
        fairness = WEIGHTS["fairness"] * max(0.0, 1 - (ngo_recent / avg_recent) / 2)

    parts = {
        "urgency": urgency, "deadline": deadline, "beneficiaries": beneficiaries,
        "waiting": waiting, "fairness": fairness,
    }
    parts = {k: round(v, 1) for k, v in parts.items()}
    return round(sum(parts.values()), 1), parts


def _recent_received(db, days=14):
    since = (svc.now() - timedelta(days=days)).strftime(svc.TS)
    rows = db.execute(
        "SELECT ngo_id, SUM(servings) s FROM distribution_history WHERE delivered_at >= ? GROUP BY ngo_id", (since,))
    return {r["ngo_id"]: r["s"] for r in rows}


def rank_requests(db):
    """Open requests (pending/partial) sorted by priority, highest first."""
    current = svc.now()
    recent = _recent_received(db)
    ngo_count = svc.scalar(db, "SELECT COUNT(*) FROM ngos") or 1
    avg_recent = sum(recent.values()) / ngo_count
    rows = db.execute(svc.REQ_SELECT + " WHERE r.status IN ('pending','partial')")
    ranked = []
    for row in rows:
        req = svc._req(row)
        if req["remaining"] <= 0:
            continue
        score, parts = priority_score(req, current, recent.get(req["ngo_id"], 0), avg_recent)
        req.update(score=score, label=priority_label(score), breakdown=parts)
        ranked.append(req)
    ranked.sort(key=lambda r: (-r["score"], r["needed_by"]))
    return ranked


# --------------------------------------------------------------------------
# Matching
# --------------------------------------------------------------------------
def _same_city(a, b):
    a, b = (a or "").strip().lower(), (b or "").strip().lower()
    return not a or not b or a == b


def suggest_requests_for_package(db, pkg, strict=False):
    """Open requests this package could serve, best first."""
    out = []
    for req in rank_requests(db):
        cat = 1.0 if req["category"] in ("Any", pkg["category"]) else (0.0 if strict else 0.55)
        if cat == 0:
            continue
        city = 1.0 if _same_city(pkg["city"], req["ngo_city"]) else 0.75
        alloc = min(pkg["remaining"], req["remaining"])
        if alloc <= 0:
            continue
        fit = 0.7 + 0.3 * (alloc / req["remaining"])
        reasons = []
        if cat < 1:
            reasons.append("different food category")
        if city < 1:
            reasons.append("different city")
        if alloc < req["remaining"]:
            reasons.append(f"covers {alloc} of {req['remaining']} servings")
        item = dict(req)
        item.update(alloc=alloc, match=round(req["score"] * cat * city * fit, 1), reasons=reasons)
        out.append(item)
    out.sort(key=lambda r: -r["match"])
    return out


def suggest_packages_for_request(db, req, strict=False):
    """Available packages that could serve this request, best first (soonest-to-expire preferred)."""
    out = []
    current = svc.now()
    for pkg in svc.available_packages(db, min_hours=1):
        cat = 1.0 if req["category"] in ("Any", pkg["category"]) else (0.0 if strict else 0.55)
        if cat == 0:
            continue
        city = 1.0 if _same_city(pkg["city"], req["ngo_city"]) else 0.75
        alloc = min(pkg["remaining"], req["remaining"])
        if alloc <= 0:
            continue
        fit = 0.7 + 0.3 * (alloc / req["remaining"])
        hours = max(0.0, (svc.parse(pkg["expiry_at"]) - current).total_seconds() / 3600)
        bonus = 1.0 + 0.25 * math.exp(-hours / 12)
        reasons = []
        if cat < 1:
            reasons.append("different food category")
        if city < 1:
            reasons.append("different city")
        if hours <= 12:
            reasons.append("expires soon – use first")
        if alloc < req["remaining"]:
            reasons.append(f"covers {alloc} of {req['remaining']} servings")
        item = dict(pkg)
        item.update(alloc=alloc, match=min(100, round(100 * cat * city * fit * bonus / 1.25)), reasons=reasons)
        out.append(item)
    out.sort(key=lambda p: -p["match"])
    return out


def auto_assign(db):
    """Serve open requests in priority order using the best-matching available packages."""
    made = []
    for req in rank_requests(db):
        for _ in range(20):
            current = svc.get_request(db, req["id"])
            if not current or current["status"] not in ("pending", "partial") or current["remaining"] <= 0:
                break
            options = suggest_packages_for_request(db, current, strict=True)
            if not options:
                break
            best = options[0]
            ok, _msg = svc.create_assignment(db, best["id"], req["id"], best["alloc"])
            if not ok:
                break
            made.append((best["id"], req["id"], best["alloc"]))
    return made


# --------------------------------------------------------------------------
# Forecasting
# --------------------------------------------------------------------------
def forecast_series(values, today, horizon=7, weeks=8, decay=0.7):
    """Forecast the next `horizon` days (starting tomorrow) of a daily series.

    `values` maps date -> amount (missing days count as 0). Prediction blends
    (65%) an exponentially weighted average of the same weekday in past weeks
    with (35%) an exponentially weighted overall daily level, so both weekly
    seasonality and recent trend are captured.
    """
    history = [(today - timedelta(days=i), values.get(today - timedelta(days=i), 0.0))
               for i in range(1, weeks * 7 + 1)]          # newest first, today excluded (incomplete)
    weekly = [sum(v for _, v in history[w * 7:(w + 1) * 7]) / 7 for w in range(weeks)]
    wts = [decay ** w for w in range(weeks)]
    level = sum(a * b for a, b in zip(weekly, wts)) / sum(wts)

    by_weekday = defaultdict(list)
    for d, v in history:
        by_weekday[d.weekday()].append(v)

    out = []
    for k in range(1, horizon + 1):
        d = today + timedelta(days=k)
        vals = by_weekday[d.weekday()]
        w = [decay ** i for i in range(len(vals))]
        same_day = sum(v * x for v, x in zip(vals, w)) / sum(w) if vals else level
        pred = 0.65 * same_day + 0.35 * level
        spread = 0.8 * pstdev(vals) if len(vals) > 1 else 0.0
        out.append({
            "date": d, "label": d.strftime("%a %d"),
            "predicted": round(pred), "low": round(max(0.0, pred - spread)), "high": round(pred + spread),
        })
    return out


def _daily(db, table, column, start):
    rows = db.execute(
        f"SELECT substr(created_at,1,10) d, SUM({column}) s FROM {table} "
        "WHERE substr(created_at,1,10) >= ? GROUP BY d", (start,))
    return {date.fromisoformat(r["d"]): float(r["s"]) for r in rows}


def forecast(db, horizon=7, weeks=8):
    today = svc.now().date()
    start = (today - timedelta(days=weeks * 7)).isoformat()
    demand = _daily(db, "requests", "servings_needed", start)
    supply = _daily(db, "food_packages", "servings", start)
    d_pred = forecast_series(demand, today, horizon, weeks)
    s_pred = forecast_series(supply, today, horizon, weeks)

    points = []
    for d, s in zip(d_pred, s_pred):
        points.append({
            "label": d["label"], "demand": d["predicted"], "demand_low": d["low"], "demand_high": d["high"],
            "supply": s["predicted"], "gap": d["predicted"] - s["predicted"],
        })
    total_demand = sum(p["demand"] for p in points)
    total_supply = sum(p["supply"] for p in points)

    since = (today - timedelta(days=28)).isoformat()
    cat_rows = db.execute(
        "SELECT category, SUM(servings_needed) s FROM requests WHERE substr(created_at,1,10) >= ? GROUP BY category ORDER BY s DESC",
        (since,)).fetchall()
    cat_total = sum(r["s"] for r in cat_rows) or 1
    categories = [{"category": r["category"], "share": round(100 * r["s"] / cat_total),
                   "predicted": round(total_demand * r["s"] / cat_total)} for r in cat_rows]

    notes = []
    if total_demand:
        peak = max(points, key=lambda p: p["demand"])
        notes.append(f"Demand is expected to peak on {peak['label']} (~{peak['demand']} servings).")
        worst = max(points, key=lambda p: p["gap"])
        if total_demand > total_supply:
            notes.append(f"Expected demand exceeds donations by ~{total_demand - total_supply} servings over the next "
                         f"{horizon} days. Recruit donors ahead of {worst['label']}, where the gap is largest (~{worst['gap']}).")
        else:
            notes.append(f"Expected donations cover predicted demand (surplus of ~{total_supply - total_demand} servings).")
    if categories:
        notes.append(f"{categories[0]['category']} accounts for {categories[0]['share']}% of recent requests.")

    return {
        "points": points,
        "max": max([p["demand"] for p in points] + [p["supply"] for p in points] + [1]),
        "total_demand": total_demand, "total_supply": total_supply,
        "history_days": len([1 for v in demand.values() if v > 0]),
        "categories": categories, "notes": notes,
    }
