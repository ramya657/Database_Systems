"""Annadaan Connect - food donation management platform (Flask + SQLite)."""
import csv
import io
import os
from datetime import datetime, timedelta

from flask import (Flask, Response, abort, flash, jsonify, redirect,
                   render_template, request, url_for)

import db as dbm
import ml
import services as svc

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-me-in-production")
dbm.init_db()
app.teardown_appcontext(dbm.close_db)


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def get_db():
    return dbm.get_db()


def form(name, default=""):
    return (request.form.get(name) or default).strip()


def form_int(name, default=0, lo=None, hi=None):
    try:
        value = int(float(request.form.get(name, default)))
    except (TypeError, ValueError):
        value = default
    if lo is not None:
        value = max(lo, value)
    if hi is not None:
        value = min(hi, value)
    return value


def norm_dt(value):
    try:
        return datetime.fromisoformat((value or "").strip().replace("T", " ")).strftime(svc.TS)
    except ValueError:
        return None


def safe_next(default):
    target = request.form.get("next") or ""
    return target if target.startswith("/") and not target.startswith("//") else default


def flash_errors(errors):
    for e in errors:
        flash(e, "error")


@app.before_request
def housekeeping():
    if request.endpoint and request.endpoint != "static":
        d = get_db()
        svc.expire_packages(d)
        d.commit()


@app.template_filter("dt")
def filter_dt(value):
    return svc.parse(value).strftime("%d %b, %I:%M %p") if value else "—"


@app.template_filter("until")
def filter_until(value):
    minutes = int((svc.parse(value) - datetime.now()).total_seconds() // 60)
    past, minutes = minutes < 0, abs(minutes)
    if minutes < 60:
        text = f"{minutes}m"
    elif minutes < 1440:
        text = f"{minutes // 60}h {minutes % 60}m"
    else:
        text = f"{minutes // 1440}d {(minutes % 1440) // 60}h"
    return f"overdue by {text}" if past else f"in {text}"


@app.template_filter("dtinput")
def filter_dtinput(value):
    return value.replace(" ", "T")[:16] if value else ""


@app.context_processor
def inject_globals():
    return {
        "CATEGORIES": svc.CATEGORIES,
        "DONOR_TYPE_OPTIONS": [(t, t) for t in svc.DONOR_TYPES],
        "CATEGORY_OPTIONS": [(c, c) for c in svc.CATEGORIES],
        "REQUEST_CATEGORY_OPTIONS": [("Any", "Any category")] + [(c, c) for c in svc.CATEGORIES],
        "URGENCY_OPTIONS": list(svc.URGENCY_LABELS.items()),
        "now": datetime.now(),
    }


@app.errorhandler(404)
def not_found(_e):
    return render_template("404.html"), 404


# --------------------------------------------------------------------------
# Dashboard
# --------------------------------------------------------------------------
@app.route("/")
def dashboard():
    d = get_db()
    return render_template(
        "dashboard.html",
        stats=svc.dashboard_stats(d),
        queue=ml.rank_requests(d)[:5],
        expiring=svc.expiring_packages(d, 12)[:6],
        recent=svc.recent_history(d, 6),
        fc=ml.forecast(d),
    )


# --------------------------------------------------------------------------
# Donors
# --------------------------------------------------------------------------
@app.route("/donors")
def donors():
    rows = get_db().execute(
        """SELECT d.*,
                  (SELECT COUNT(*) FROM food_packages p WHERE p.donor_id = d.id) AS packages,
                  (SELECT COALESCE(SUM(h.servings),0) FROM distribution_history h WHERE h.donor_id = d.id) AS delivered
           FROM donors d ORDER BY d.name""").fetchall()
    return render_template("donors.html", donors=rows)


@app.route("/donors/new", methods=["GET", "POST"])
@app.route("/donors/<int:donor_id>/edit", methods=["GET", "POST"])
def donor_form(donor_id=None):
    d = get_db()
    row = d.execute("SELECT * FROM donors WHERE id=?", (donor_id,)).fetchone() if donor_id else None
    if donor_id and not row:
        abort(404)
    if request.method == "POST":
        data = (form("name"), form("donor_type", "Restaurant"), form("contact_person"), form("phone"),
                form("email"), form("address"), form("city"))
        if not data[0]:
            flash_errors(["Donor name is required."])
        else:
            if row:
                d.execute("""UPDATE donors SET name=?, donor_type=?, contact_person=?, phone=?, email=?,
                             address=?, city=? WHERE id=?""", data + (donor_id,))
                new_id = donor_id
            else:
                new_id = d.execute("""INSERT INTO donors (name, donor_type, contact_person, phone, email, address, city)
                                      VALUES (?,?,?,?,?,?,?)""", data).lastrowid
            d.commit()
            flash("Donor saved.", "success")
            return redirect(url_for("donor_detail", donor_id=new_id))
    values = request.form if request.method == "POST" else (dict(row) if row else {})
    return render_template("donor_form.html", v=values, editing=bool(donor_id), donor_id=donor_id)


@app.route("/donors/<int:donor_id>")
def donor_detail(donor_id):
    d = get_db()
    donor = d.execute("SELECT * FROM donors WHERE id=?", (donor_id,)).fetchone() or abort(404)
    packages = [svc._pkg(r) for r in d.execute(svc.PKG_SELECT + " WHERE p.donor_id=? ORDER BY p.created_at DESC LIMIT 50", (donor_id,))]
    total = svc.scalar(d, "SELECT COALESCE(SUM(servings),0) FROM distribution_history WHERE donor_id=?", (donor_id,))
    meals_by_ngo = d.execute(
        """SELECT n.name, SUM(h.servings) s FROM distribution_history h JOIN ngos n ON n.id=h.ngo_id
           WHERE h.donor_id=? GROUP BY n.id ORDER BY s DESC LIMIT 5""", (donor_id,)).fetchall()
    return render_template("donor_detail.html", donor=donor, packages=packages, total=total, top_ngos=meals_by_ngo)


# --------------------------------------------------------------------------
# NGOs
# --------------------------------------------------------------------------
@app.route("/ngos")
def ngos():
    rows = get_db().execute(
        """SELECT n.*,
                  (SELECT COUNT(*) FROM requests r WHERE r.ngo_id = n.id) AS requests,
                  (SELECT COALESCE(SUM(h.servings),0) FROM distribution_history h WHERE h.ngo_id = n.id) AS received
           FROM ngos n ORDER BY n.name""").fetchall()
    return render_template("ngos.html", ngos=rows)


@app.route("/ngos/new", methods=["GET", "POST"])
@app.route("/ngos/<int:ngo_id>/edit", methods=["GET", "POST"])
def ngo_form(ngo_id=None):
    d = get_db()
    row = d.execute("SELECT * FROM ngos WHERE id=?", (ngo_id,)).fetchone() if ngo_id else None
    if ngo_id and not row:
        abort(404)
    if request.method == "POST":
        data = (form("name"), form("contact_person"), form("phone"), form("email"), form("address"),
                form("city"), form_int("beneficiaries", 0, 0), form_int("capacity", 0, 0))
        if not data[0]:
            flash_errors(["Organisation name is required."])
        else:
            if row:
                d.execute("""UPDATE ngos SET name=?, contact_person=?, phone=?, email=?, address=?, city=?,
                             beneficiaries=?, capacity=? WHERE id=?""", data + (ngo_id,))
                new_id = ngo_id
            else:
                new_id = d.execute("""INSERT INTO ngos (name, contact_person, phone, email, address, city, beneficiaries, capacity)
                                      VALUES (?,?,?,?,?,?,?,?)""", data).lastrowid
            d.commit()
            flash("NGO saved.", "success")
            return redirect(url_for("ngo_detail", ngo_id=new_id))
    values = request.form if request.method == "POST" else (dict(row) if row else {})
    return render_template("ngo_form.html", v=values, editing=bool(ngo_id), ngo_id=ngo_id)


@app.route("/ngos/<int:ngo_id>")
def ngo_detail(ngo_id):
    d = get_db()
    ngo = d.execute("SELECT * FROM ngos WHERE id=?", (ngo_id,)).fetchone() or abort(404)
    reqs = [svc._req(r) for r in d.execute(svc.REQ_SELECT + " WHERE r.ngo_id=? ORDER BY r.created_at DESC LIMIT 50", (ngo_id,))]
    received = svc.scalar(d, "SELECT COALESCE(SUM(servings),0) FROM distribution_history WHERE ngo_id=?", (ngo_id,))
    top_donors = d.execute(
        """SELECT dn.name, SUM(h.servings) s FROM distribution_history h JOIN donors dn ON dn.id=h.donor_id
           WHERE h.ngo_id=? GROUP BY dn.id ORDER BY s DESC LIMIT 5""", (ngo_id,)).fetchall()
    return render_template("ngo_detail.html", ngo=ngo, requests=reqs, received=received, top_donors=top_donors)


# --------------------------------------------------------------------------
# Food packages
# --------------------------------------------------------------------------
@app.route("/packages")
def packages():
    status = request.args.get("status", "")
    category = request.args.get("category", "")
    rows = svc.list_packages(get_db(), status or None, category or None)
    return render_template("packages.html", packages=rows, status=status, category=category)


@app.route("/packages/new", methods=["GET", "POST"])
def package_new():
    d = get_db()
    donors_list = d.execute("SELECT id, name, city, address FROM donors ORDER BY name").fetchall()
    if not donors_list:
        flash("Add a donor first, then you can list food packages.", "error")
        return redirect(url_for("donor_form"))
    if request.method == "POST":
        errors = []
        donor = d.execute("SELECT * FROM donors WHERE id=?", (form_int("donor_id"),)).fetchone()
        servings = form_int("servings", 0)
        expiry = norm_dt(form("expiry_at"))
        prepared = norm_dt(form("prepared_at")) if form("prepared_at") else None
        if not donor:
            errors.append("Please choose a donor.")
        if not form("food_name"):
            errors.append("Food name is required.")
        if form("category") not in svc.CATEGORIES:
            errors.append("Please choose a category.")
        if servings <= 0:
            errors.append("Servings must be at least 1.")
        if not expiry:
            errors.append("Please provide a valid 'use before' date and time.")
        elif svc.parse(expiry) <= datetime.now():
            errors.append("The 'use before' time must be in the future.")
        if errors:
            flash_errors(errors)
        else:
            pid = d.execute(
                """INSERT INTO food_packages (donor_id, food_name, category, servings, quantity_note, pickup_address,
                                              city, prepared_at, expiry_at, notes, created_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                (donor["id"], form("food_name"), form("category"), servings, form("quantity_note"),
                 form("pickup_address") or donor["address"], form("city") or donor["city"], prepared, expiry,
                 form("notes"), svc.now_str())).lastrowid
            d.commit()
            flash("Food package listed. It is now visible for matching.", "success")
            return redirect(url_for("package_detail", package_id=pid))
    if request.method == "POST":
        values = request.form
    else:
        values = {"donor_id": request.args.get("donor_id", ""), "servings": 50,
                  "expiry_at": (datetime.now() + timedelta(hours=6)).strftime("%Y-%m-%dT%H:%M")}
    donor_options = [("", "Choose a donor…")] + [(r["id"], f"{r['name']} ({r['city']})" if r["city"] else r["name"]) for r in donors_list]
    return render_template("package_form.html", donor_options=donor_options, v=values)


@app.route("/packages/<int:package_id>")
def package_detail(package_id):
    d = get_db()
    pkg = svc.get_package(d, package_id) or abort(404)
    suggestions = ml.suggest_requests_for_package(d, pkg)[:6] if pkg["status"] == "available" and pkg["remaining"] > 0 else []
    assignments = svc.assignments_for(d, "a.package_id = ?", (package_id,))
    return render_template("package_detail.html", p=pkg, suggestions=suggestions, assignments=assignments)


@app.post("/packages/<int:package_id>/withdraw")
def package_withdraw(package_id):
    ok, msg = svc.withdraw_package(get_db(), package_id)
    flash(msg, "success" if ok else "error")
    return redirect(url_for("package_detail", package_id=package_id))


# --------------------------------------------------------------------------
# Requests
# --------------------------------------------------------------------------
@app.route("/requests")
def requests_list():
    d = get_db()
    status = request.args.get("status", "")
    rows = svc.list_requests(d, status or None)
    ranked = {r["id"]: r for r in ml.rank_requests(d)}
    for r in rows:
        if r["id"] in ranked:
            r["score"], r["label"] = ranked[r["id"]]["score"], ranked[r["id"]]["label"]
    return render_template("requests.html", requests=rows, status=status)


@app.route("/requests/new", methods=["GET", "POST"])
def request_new():
    d = get_db()
    ngo_list = d.execute("SELECT id, name, city, beneficiaries FROM ngos ORDER BY name").fetchall()
    if not ngo_list:
        flash("Register an NGO first, then it can request food.", "error")
        return redirect(url_for("ngo_form"))
    if request.method == "POST":
        errors = []
        ngo = d.execute("SELECT * FROM ngos WHERE id=?", (form_int("ngo_id"),)).fetchone()
        servings = form_int("servings_needed", 0)
        needed_by = norm_dt(form("needed_by"))
        category = form("category", "Any")
        if not ngo:
            errors.append("Please choose an NGO.")
        if servings <= 0:
            errors.append("Servings needed must be at least 1.")
        if category != "Any" and category not in svc.CATEGORIES:
            errors.append("Invalid food category.")
        if not needed_by:
            errors.append("Please provide a valid 'needed by' date and time.")
        if errors:
            flash_errors(errors)
        else:
            people = form_int("beneficiaries", 0, 0) or ngo["beneficiaries"] or servings
            rid = d.execute(
                """INSERT INTO requests (ngo_id, category, servings_needed, beneficiaries, urgency, needed_by, notes, created_at)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (ngo["id"], category, servings, people, form_int("urgency", 3, 1, 5), needed_by,
                 form("notes"), svc.now_str())).lastrowid
            d.commit()
            flash("Request submitted. Matching food will be suggested automatically.", "success")
            return redirect(url_for("request_detail", request_id=rid))
    if request.method == "POST":
        values = request.form
    else:
        values = {"ngo_id": request.args.get("ngo_id", ""), "servings_needed": 50, "urgency": 3,
                  "needed_by": (datetime.now() + timedelta(hours=12)).strftime("%Y-%m-%dT%H:%M")}
    ngo_options = [("", "Choose an NGO…")] + [(r["id"], f"{r['name']} ({r['city']})" if r["city"] else r["name"]) for r in ngo_list]
    return render_template("request_form.html", ngo_options=ngo_options, v=values)


@app.route("/requests/<int:request_id>")
def request_detail(request_id):
    d = get_db()
    req = svc.get_request(d, request_id) or abort(404)
    score = None
    for r in ml.rank_requests(d):
        if r["id"] == request_id:
            score = r
            break
    suggestions = ml.suggest_packages_for_request(d, req)[:6] if score else []
    assignments = svc.assignments_for(d, "a.request_id = ?", (request_id,))
    return render_template("request_detail.html", r=req, score=score, suggestions=suggestions, assignments=assignments)


@app.post("/requests/<int:request_id>/cancel")
def request_cancel(request_id):
    ok, msg = svc.cancel_request(get_db(), request_id)
    flash(msg, "success" if ok else "error")
    return redirect(url_for("request_detail", request_id=request_id))


# --------------------------------------------------------------------------
# Assignments
# --------------------------------------------------------------------------
@app.route("/assignments")
def assignments():
    status = request.args.get("status", "")
    d = get_db()
    if status in ("assigned", "picked_up", "delivered", "cancelled"):
        rows = svc.assignments_for(d, "a.status = ?", (status,))
    else:
        rows = svc.assignments_for(d, "1=1")
    counts = {r["status"]: r["c"] for r in d.execute("SELECT status, COUNT(*) c FROM assignments GROUP BY status")}
    return render_template("assignments.html", assignments=rows, status=status, counts=counts)


@app.post("/assign")
def assign():
    ok, msg = svc.create_assignment(get_db(), form_int("package_id"), form_int("request_id"),
                                    request.form.get("servings"))
    flash(msg, "success" if ok else "error")
    return redirect(safe_next(url_for("assignments")) if ok else safe_next(url_for("dashboard")))


@app.post("/assignments/<int:assignment_id>/status")
def assignment_status(assignment_id):
    ok, msg = svc.update_assignment_status(get_db(), assignment_id, form("status"))
    flash(msg, "success" if ok else "error")
    return redirect(safe_next(url_for("assignments")))


@app.post("/auto-assign")
def auto_assign():
    made = ml.auto_assign(get_db())
    if made:
        flash(f"Smart matching created {len(made)} assignment(s) covering {sum(m[2] for m in made)} servings, "
              "highest-priority requests first.", "success")
    else:
        flash("Nothing to match right now – there are no compatible open requests and available packages.", "info")
    return redirect(safe_next(url_for("assignments")))


# --------------------------------------------------------------------------
# History & insights
# --------------------------------------------------------------------------
@app.route("/history")
def history():
    d = get_db()
    rows = d.execute(
        """SELECT h.*, dn.name AS donor_name, n.name AS ngo_name
           FROM distribution_history h JOIN donors dn ON dn.id=h.donor_id JOIN ngos n ON n.id=h.ngo_id
           ORDER BY h.delivered_at DESC LIMIT 200""").fetchall()
    totals = {
        "servings": svc.scalar(d, "SELECT COALESCE(SUM(servings),0) FROM distribution_history"),
        "deliveries": svc.scalar(d, "SELECT COUNT(*) FROM distribution_history"),
        "donors": svc.scalar(d, "SELECT COUNT(DISTINCT donor_id) FROM distribution_history"),
        "ngos": svc.scalar(d, "SELECT COUNT(DISTINCT ngo_id) FROM distribution_history"),
    }
    top_donors = d.execute("""SELECT dn.id, dn.name, SUM(h.servings) s FROM distribution_history h
                              JOIN donors dn ON dn.id=h.donor_id GROUP BY dn.id ORDER BY s DESC LIMIT 5""").fetchall()
    top_ngos = d.execute("""SELECT n.id, n.name, SUM(h.servings) s FROM distribution_history h
                            JOIN ngos n ON n.id=h.ngo_id GROUP BY n.id ORDER BY s DESC LIMIT 5""").fetchall()
    return render_template("history.html", rows=rows, totals=totals, top_donors=top_donors, top_ngos=top_ngos)


@app.route("/history.csv")
def history_csv():
    rows = get_db().execute(
        """SELECT h.delivered_at, dn.name AS donor, n.name AS ngo, h.food_name, h.category, h.servings
           FROM distribution_history h JOIN donors dn ON dn.id=h.donor_id JOIN ngos n ON n.id=h.ngo_id
           ORDER BY h.delivered_at DESC""").fetchall()
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["delivered_at", "donor", "ngo", "food", "category", "servings"])
    writer.writerows([tuple(r) for r in rows])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=distribution_history.csv"})


@app.route("/insights")
def insights():
    d = get_db()
    return render_template("insights.html", fc=ml.forecast(d), queue=ml.rank_requests(d), weights=ml.WEIGHTS)


@app.route("/api/forecast")
def api_forecast():
    fc = ml.forecast(get_db())
    return jsonify({k: fc[k] for k in ("points", "total_demand", "total_supply", "categories", "notes")})


@app.route("/api/priority-queue")
def api_queue():
    return jsonify([{k: r[k] for k in ("id", "ngo_name", "category", "remaining", "needed_by", "urgency",
                                       "score", "label", "breakdown")} for r in ml.rank_requests(get_db())])


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=True)
