"""Fill the database with realistic demo data (8 weeks of history + a live queue).

Usage:  python seed.py            # seeds only if the database is empty
        python seed.py --force    # wipes everything and re-seeds
"""
import os
import random
import sys
from datetime import datetime, timedelta

import db as dbm
import services as svc

random.seed(7)
FMT = svc.TS

DONORS = [
    ("Spice Route Restaurant", "Restaurant", "Meera Nair", "+91 90000 10001", "meera@spiceroute.example", "12 Jubilee Hills Road", "Hyderabad"),
    ("Sri Sai Caterers", "Caterer", "Ramesh Reddy", "+91 90000 10002", "ramesh@srisai.example", "45 Madhapur Main Road", "Hyderabad"),
    ("GreenBasket Supermarket", "Supermarket", "Anita Sharma", "+91 90000 10003", "anita@greenbasket.example", "8 Kukatpally Housing Board", "Hyderabad"),
    ("Royal Orchid Banquet Hall", "Banquet Hall", "Vikram Rao", "+91 90000 10004", "vikram@royalorchid.example", "2 Begumpet Circle", "Secunderabad"),
    ("Annapurna Canteen", "Institution", "Lakshmi Devi", "+91 90000 10005", "lakshmi@annapurna.example", "Lakeview College Campus", "Secunderabad"),
    ("Sunrise Bakery", "Bakery", "Imran Khan", "+91 90000 10006", "imran@sunrise.example", "19 Tarnaka Road", "Secunderabad"),
    ("Fresh Farms Wholesale Market", "Wholesale Market", "Gopal Yadav", "+91 90000 10007", "gopal@freshfarms.example", "Gaddiannaram Market Yard", "Hyderabad"),
    ("Hotel Lakeside Kitchen", "Restaurant", "Priya Menon", "+91 90000 10008", "priya@lakeside.example", "31 Banjara Hills", "Hyderabad"),
]

NGOS = [
    ("Asha Kiran Orphanage", "Sister Mary", "+91 91000 20001", "ashakiran@ngo.example", "5 Ameerpet Lane", "Hyderabad", 45, 120),
    ("Hope Foundation Shelter", "Karthik Iyer", "+91 91000 20002", "hope@ngo.example", "22 Dilsukhnagar", "Hyderabad", 80, 200),
    ("Seva Samithi Old Age Home", "Rukmini Amma", "+91 91000 20003", "seva@ngo.example", "14 Secunderabad Club Road", "Secunderabad", 50, 90),
    ("Akshaya Community Kitchen", "Mohan Das", "+91 91000 20004", "akshaya@ngo.example", "Plot 7, Mehdipatnam", "Hyderabad", 150, 350),
    ("Little Stars Children's Home", "Fatima Begum", "+91 91000 20005", "littlestars@ngo.example", "9 Tarnaka Colony", "Secunderabad", 40, 100),
    ("Night Shelter Trust", "Suresh Babu", "+91 91000 20006", "nightshelter@ngo.example", "Under Flyover, Koti", "Hyderabad", 100, 160),
    ("Jyothi Women's Care Centre", "Padma Kumari", "+91 91000 20007", "jyothi@ngo.example", "18 Kothapet", "Hyderabad", 60, 110),
    ("Roti Bank Collective", "Arjun Verma", "+91 91000 20008", "rotibank@ngo.example", "3 Malkajgiri", "Secunderabad", 120, 300),
]

FOODS = {
    "Cooked Meals": ["Veg Biryani", "Dal & Rice", "Chapati & Curry", "Sambar Rice", "Mixed Veg Pulao"],
    "Bakery": ["Bread loaves", "Buns & rolls", "Biscuit trays"],
    "Fruits & Vegetables": ["Mixed vegetables", "Seasonal fruits", "Leafy greens"],
    "Dairy": ["Milk packets", "Curd cups"],
    "Packaged Food": ["Packed snacks", "Instant noodle cartons"],
    "Grains & Staples": ["Rice sacks", "Atta & dal bags"],
}
SHELF_HOURS = {"Cooked Meals": (6, 10), "Bakery": (24, 48), "Fruits & Vegetables": (36, 72),
               "Dairy": (24, 48), "Packaged Food": (72, 160), "Grains & Staples": (96, 200)}
DONOR_CATEGORIES = {
    "Restaurant": ["Cooked Meals"], "Caterer": ["Cooked Meals"], "Banquet Hall": ["Cooked Meals"],
    "Institution": ["Cooked Meals"], "Bakery": ["Bakery"],
    "Supermarket": ["Packaged Food", "Dairy", "Bakery", "Fruits & Vegetables"],
    "Wholesale Market": ["Fruits & Vegetables", "Grains & Staples"],
}
PKG_PER_DAY = [2, 2, 2, 2, 3, 4, 3]   # Mon..Sun
REQ_PER_DAY = [2, 2, 2, 3, 4, 5, 5]


def fmt(dt):
    return dt.strftime(FMT)


def main(force=False):
    if force and os.path.exists(dbm.DB_PATH):
        os.remove(dbm.DB_PATH)
    dbm.init_db()
    db = dbm.connect()
    if svc.scalar(db, "SELECT COUNT(*) FROM donors") and not force:
        print("Database already has data. Run `python seed.py --force` to reset it.")
        return

    donors = []
    for name, dtype, person, phone, email, addr, city in DONORS:
        did = db.execute("INSERT INTO donors (name, donor_type, contact_person, phone, email, address, city) VALUES (?,?,?,?,?,?,?)",
                         (name, dtype, person, phone, email, addr, city)).lastrowid
        donors.append({"id": did, "type": dtype, "address": addr, "city": city})
    ngos = []
    for name, person, phone, email, addr, city, people, cap in NGOS:
        nid = db.execute("INSERT INTO ngos (name, contact_person, phone, email, address, city, beneficiaries, capacity) VALUES (?,?,?,?,?,?,?,?)",
                         (name, person, phone, email, addr, city, people, cap)).lastrowid
        ngos.append({"id": nid, "people": people, "city": city})

    now = datetime.now()
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)

    # ---- 8 weeks of history -------------------------------------------------
    pkgs, reqs = [], []
    for back in range(56, 0, -1):
        day = today - timedelta(days=back)
        wd = day.weekday()
        for _ in range(max(0, round(random.gauss(PKG_PER_DAY[wd], 0.8)))):
            donor = random.choice(donors)
            cat = random.choice(DONOR_CATEGORIES[donor["type"]])
            created = day + timedelta(hours=random.randint(8, 20), minutes=random.randint(0, 59))
            lo, hi = SHELF_HOURS[cat]
            servings = random.randint(40, 170) + (30 if wd >= 5 and cat == "Cooked Meals" else 0)
            pkgs.append({"donor": donor, "cat": cat, "name": random.choice(FOODS[cat]), "servings": servings,
                         "created": created, "expiry": created + timedelta(hours=min(random.randint(lo, hi), 36)),
                         "left": servings})
        for _ in range(max(0, round(random.gauss(REQ_PER_DAY[wd], 0.9)))):
            ngo = random.choice(ngos)
            created = day + timedelta(hours=random.randint(7, 18), minutes=random.randint(0, 59))
            cat = random.choices(["Any"] + svc.CATEGORIES, weights=[4, 6, 1, 1, 1, 1, 1])[0]
            need = random.randint(25, 130) + (20 if wd >= 5 else 0)
            reqs.append({"ngo": ngo, "cat": cat, "need": need, "created": created,
                         "needed_by": created + timedelta(hours=random.randint(10, 36)),
                         "urgency": random.choices([1, 2, 3, 4, 5], weights=[1, 3, 4, 3, 1])[0], "got": 0, "links": []})

    for p in pkgs:
        p["id"] = None
    reqs.sort(key=lambda r: r["created"])
    for r in reqs:
        for p in sorted(pkgs, key=lambda x: x["created"]):
            if r["got"] >= r["need"]:
                break
            if p["left"] <= 0 or p["created"] > r["created"] + timedelta(hours=6) or p["expiry"] <= r["created"]:
                continue
            if r["cat"] not in ("Any", p["cat"]):
                continue
            take = min(p["left"], r["need"] - r["got"])
            p["left"] -= take
            r["got"] += take
            r["links"].append((p, take))

    for p in pkgs:
        allocated = p["servings"] - p["left"]
        status = "delivered" if p["left"] == 0 else ("expired" if p["expiry"] < now else "available")
        p["id"] = db.execute(
            """INSERT INTO food_packages (donor_id, food_name, category, servings, pickup_address, city, prepared_at,
                                          expiry_at, status, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (p["donor"]["id"], p["name"], p["cat"], p["servings"], p["donor"]["address"], p["donor"]["city"],
             fmt(p["created"] - timedelta(hours=1)), fmt(p["expiry"]), status, fmt(p["created"]))).lastrowid
        p["allocated"] = allocated

    for r in reqs:
        if r["got"] >= r["need"]:
            status = "fulfilled"
        elif r["needed_by"] <= now:
            status = "fulfilled" if r["got"] > 0 else "cancelled"   # closed after partial delivery / unmet
        else:
            status = "partial" if r["got"] > 0 else "pending"
        r["id"] = db.execute(
            """INSERT INTO requests (ngo_id, category, servings_needed, beneficiaries, urgency, needed_by, status, created_at)
               VALUES (?,?,?,?,?,?,?,?)""",
            (r["ngo"]["id"], r["cat"], r["need"], r["ngo"]["people"], r["urgency"], fmt(r["needed_by"]), status,
             fmt(r["created"]))).lastrowid
        for p, take in r["links"]:
            start = max(r["created"], p["created"])
            picked = start + timedelta(hours=random.randint(1, 2))
            delivered = min(picked + timedelta(hours=random.randint(1, 2)), now - timedelta(minutes=5))
            aid = db.execute(
                """INSERT INTO assignments (package_id, request_id, servings, status, assigned_at, picked_up_at, delivered_at)
                   VALUES (?,?,?,?,?,?,?)""",
                (p["id"], r["id"], take, "delivered", fmt(start), fmt(min(picked, delivered)), fmt(delivered))).lastrowid
            db.execute(
                """INSERT INTO distribution_history (assignment_id, donor_id, ngo_id, food_name, category, servings, delivered_at)
                   VALUES (?,?,?,?,?,?,?)""",
                (aid, p["donor"]["id"], r["ngo"]["id"], p["name"], p["cat"], take, fmt(delivered)))

    # ---- live data (today) ------------------------------------------------
    by_name = {d["address"]: d for d in donors}

    def live_package(donor_idx, name, cat, servings, expiry_hours, created_hours_ago=1, note=""):
        d = donors[donor_idx]
        created = now - timedelta(hours=created_hours_ago)
        return db.execute(
            """INSERT INTO food_packages (donor_id, food_name, category, servings, pickup_address, city, prepared_at,
                                          expiry_at, notes, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (d["id"], name, cat, servings, d["address"], d["city"], fmt(created - timedelta(hours=1)),
             fmt(now + timedelta(hours=expiry_hours)), note, fmt(created))).lastrowid

    def live_request(ngo_idx, cat, servings, urgency, hours_left, waited_hours, note=""):
        n = ngos[ngo_idx]
        return db.execute(
            """INSERT INTO requests (ngo_id, category, servings_needed, beneficiaries, urgency, needed_by, notes, created_at)
               VALUES (?,?,?,?,?,?,?,?)""",
            (n["id"], cat, servings, n["people"], urgency, fmt(now + timedelta(hours=hours_left)), note,
             fmt(now - timedelta(hours=waited_hours)))).lastrowid

    p_biryani = live_package(3, "Veg Biryani – wedding surplus", "Cooked Meals", 120, 5, 1, "Packed in sealed trays, pick up from service gate.")
    p_bread = live_package(5, "Fresh bread loaves & buns", "Bakery", 60, 20, 2)
    p_veg = live_package(6, "Mixed vegetables crates", "Fruits & Vegetables", 80, 36, 3)
    p_dal = live_package(4, "Dal & rice packets", "Cooked Meals", 90, 8, 1)
    p_snack = live_package(2, "Packed biscuits & snacks cartons", "Packaged Food", 150, 120, 4)
    p_milk = live_package(2, "Milk packets (near date)", "Dairy", 70, 14, 2)

    r_night = live_request(5, "Cooked Meals", 100, 5, 4, 3, "Winter intake is high; cannot cook tonight.")
    r_orphan = live_request(0, "Any", 60, 4, 10, 5)
    r_seva = live_request(2, "Cooked Meals", 50, 3, 12, 6)
    live_request(3, "Fruits & Vegetables", 70, 3, 30, 8)
    live_request(4, "Bakery", 40, 2, 24, 4)
    live_request(6, "Dairy", 40, 4, 16, 2)
    live_request(7, "Any", 120, 2, 48, 10)
    db.commit()

    # a couple of assignments already in motion
    svc.create_assignment(db, p_dal, r_seva, 50)
    svc.create_assignment(db, p_biryani, r_night, 60)
    a = db.execute("SELECT id FROM assignments ORDER BY id DESC LIMIT 1").fetchone()["id"]
    svc.update_assignment_status(db, a, "picked_up")
    svc.expire_packages(db)
    db.commit()

    print("Seeded:",
          svc.scalar(db, "SELECT COUNT(*) FROM donors"), "donors,",
          svc.scalar(db, "SELECT COUNT(*) FROM ngos"), "NGOs,",
          svc.scalar(db, "SELECT COUNT(*) FROM food_packages"), "packages,",
          svc.scalar(db, "SELECT COUNT(*) FROM requests"), "requests,",
          svc.scalar(db, "SELECT COUNT(*) FROM distribution_history"), "deliveries.")
    db.close()


if __name__ == "__main__":
    main(force="--force" in sys.argv)
